import { User } from "./user.model";

class UserService {
   
    users:User[] = [];
    constructor() {
        this.users.push({"id":1,"name":"banu","password":"secret"});
        this.users.push({"id":1,"name":"test","password":"test"});
    }   

    getUsers():User[] {
        return this.users;
    }

    getUser(id:number)  {
        return this.users.find(u => u.id == id);
    }

    validate(name: string, password: string) {
        return this.users.find(u => u.name == name && u.password == password);
    }

}

export default new UserService();