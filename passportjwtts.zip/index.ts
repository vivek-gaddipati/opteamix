import express from 'express';
import jwt from 'jsonwebtoken';
import passport from 'passport';

import passportJWtInit from './auth';
import userService from './user.service';

passportJWtInit();

const app:express.Application = express();

app.use(express.json());

app.use(passport.initialize());


app.get("/", function(req, res) {
    res.json({message: "Express is up!"});
  });
  
  app.post("/login", function(req, res) {
    if(req.body.name && req.body.password){
      var name = req.body.name;
      var password = req.body.password;
    }
    var user  = userService.validate(name,password);
    if( !user ){
      res.status(401).json({message:"no such user found"});
    }
    else  {
      var payload = {id: user.id};
      var token = jwt.sign(payload, 'TopS3r3t123');
      res.json({message: "ok", token: token});
    } 
  });
  
  app.get("/secret", passport.authenticate('jwt', { session: false }), function(req, res){
    res.json({message: "Success! You can not see this without a token"});
  });
  
  
  app.listen(3000, function() {
    console.log("Express Passport app running");
  });