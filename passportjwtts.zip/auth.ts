import passport from 'passport';
import passportJWT from 'passport-jwt';
import userService from './user.service';

export default function passportJWtInit() {
var ExtractJwt = passportJWT.ExtractJwt;
var JwtStrategy = passportJWT.Strategy;


var jwtOptions:passportJWT.StrategyOptions = {
    jwtFromRequest:ExtractJwt.fromAuthHeaderAsBearerToken(),
    secretOrKey: 'TopS3r3t123'
}


var strategy = new JwtStrategy(jwtOptions, function(jwt_payload, next) {
  console.log('payload received', jwt_payload);
  const id:number = +jwt_payload.id;
  var user = userService.getUser(id);
  if (user) {
    next(null, user);
  } else {
    next(null, false);
  }
});

passport.use(strategy);

}