docker build -t load-balanced-app .



docker run -e "MESSAGE=First instance" -p 8081:8080 -d load-balanced-app

docker run -e "MESSAGE=Second instance" -p 8082:8080 -d load-balanced-app

Run:
http://localhost:8081 and http://localhost:8082