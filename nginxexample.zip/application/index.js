var http = require('http');
var fs = require('fs');
http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/html'});
  res.end(`&lt;h1&gt;:-) :${process.env.MESSAGE}&lt;/h1&gt;`);
}).listen(8080);