const express = require('express');
const path = require('path');

const helmet = require('helmet');

let app = new express();

app.use(helmet.frameguard({ action: 'deny' }));


app.use(express.static(path.join(__dirname, "public")));


app.listen(3000);
