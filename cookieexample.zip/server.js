const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const session = require('express-session');
const bodyParser = require('body-parser');

let app = new express();

let index = require('./routes/index');
let user = require('./routes/user');

app.use(bodyParser.urlencoded());
app.use(cookieParser());
app.use(session({
    "secret" : "secret123",
    "saveUninitialized" : false,
    "resave" : true
}));

app.all("*", (req,res,next) => {
    console.log(req.originalUrl);
    console.log(req.session);
    if(req.originalUrl == '/login.html' || 
        req.originalUrl == '/index.html' || 
        req.originalUrl === '/user/auth' ||
        (req.session.user !== null &&
        req.session.user !== undefined) ) {
            console.log("Proceeding !!!");
            next();
        } else {
            res.redirect("/login.html");
        }
});


app.use(express.static(path.join(__dirname, "public")));


app.use("/", index);
app.use("/user",user);


app.listen(3000);
