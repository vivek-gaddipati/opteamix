const express = require('express');

const router = express.Router();

router.post("/auth", (req, res) => {
    var email = req.body.email;
    var pwd = req.body.password;
    // var session = req.session;
    req.session.user = email;
    console.log("====> ",req.session, email);
    res.redirect("/index.html");
});

router.get("/logout", (req,res) => {
    var ses = req.session;
    ses.destroy();
    res.redirect("/index.html");
});

module.exports = router;