//DefinitelyTyped 

const monica:Person = {
    firstName: 'Monica',
    lastName: 'Geller',
    age: 24
}

const getName: GetFullName = (p:Person) => p.firstName + " " + p.lastName;

console.log(getName(monica));

